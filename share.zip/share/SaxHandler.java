package pack;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


public class SaxHandler extends DefaultHandler {

	  public static void main(String args[])
	  {
		  new SaxHandler().parseXmlDocument();
		}

	  public void parseXmlDocument() {
			try {
				// getting SAXParserFactory instance
				SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();

				// Getting SAXParser object from AXParserFactory instance
				SAXParser saxParser = saxParserFactory.newSAXParser();

				// Parsing XML Document by calling parse method of SAXParser class
				saxParser.parse("Book.xml", this);
				

			} catch (Exception e) {
				e.printStackTrace();
			}
		}


    public void startDocument() throws SAXException {
        System.out.println(" document starts ");
    }
    

    public void endDocument() throws SAXException {
        System.out.println("document  ends ");
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes)  throws SAXException {

        System.out.println("start element    : " + qName+" Attributes "+attributes.getQName(0)+attributes.getQName(1));
        
    }

    public void endElement(String uri, String localName, String qName) throws SAXException {
        System.out.println("end element      : " +qName);
    }

    public void characters(char ch[],int start,int length)  throws SAXException
    {
        System.out.println("start characters : " + new String(ch, start, length));
    }
    
	  }



