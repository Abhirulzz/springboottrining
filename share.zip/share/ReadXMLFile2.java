package pack;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadXMLFile2 { 
	

	public static void main(String argv[]) { 
	
		try {  
	 	File file = new File("Book.xml");  
		DocumentBuilderFactory dbf =  DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(file); 
		System.out.println("root");
		System.out.println(doc.getDocumentElement().getNodeName());//Root
		System.out.println(doc.getFirstChild().getNodeName());//Root
	
	    Node n=doc.getFirstChild();
	    

		  NodeList nList=n.getChildNodes();
		  
		 // System.out.println("checking "+nList.item(1).getChildNodes();
		  
		  NodeList nList4=nList.item(1).getChildNodes();
		  
	//	 System.out.println("checking "+nList4.item(1).getNodeName().get);
		 
		  Node an1,an2=null;
		  for (int i=0;i<nList.getLength();i++)
		  {
			  
			  an1=nList.item(i);
			  
			  //NamedNodeMap attributes = an1.getAttributes();

		   /*  // for (int a = 0; a < attributes.getLength(); a++) {
		        Node theAttribute1 = attributes.item(0);
		        System.out.println("ff Attributes "+theAttribute1.getNodeName() + "=" + theAttribute1.getNodeValue());
		     // }  
*/			 
			  if (an1.getNodeType()==Node.ELEMENT_NODE)
				  
			  {
				  System.out.println("Node name "+an1.getNodeName());
					
				  NodeList nList2=an1.getChildNodes();
					 
					 for ( int j=0;j<nList2.getLength();j++)
					 {
						  an2=nList2.item(j);
							 
						  if (an2.getNodeType()==Node.ELEMENT_NODE)
						  {
					 System.out.println("Child Node name "+an2.getNodeName());
					 System.out.println("Node value "+an2.getFirstChild().getNodeValue());//Node value
				   	    
						  NamedNodeMap attributes1 = an2.getAttributes();

					      for (int a = 0; a < attributes1.getLength(); a++) {
					        Node theAttribute = attributes1.item(a);
					        System.out.println("Attributes "+theAttribute.getNodeName() + "=" + theAttribute.getNodeValue());
					      }
					 } 
			      
			  }
		  }
		 
		  }
		 

		  
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		
	}
	
}